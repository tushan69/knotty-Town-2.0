import{c as S}from"./index-qXCim9PF.js";var e=(s=>(s.OVERSIZED="Oversized Tees",s.GRAPHIC="Graphic Collection",s.MINIMAL="Minimalist",s.CUSTOM="Custom Lab",s.ANIME="Anime Edition",s.CARS="Automotive Series",s.VAULT="Secret Vault",s.METAL_POSTERS="Metal Posters",s.SHIRTS="Shirts",s.POLO_SHIRTS="Polo Shirts",s.FORMAL_DRESS="Formal Dress",s.WOMEN_DRESSES="Women Dresses",s))(e||{});/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=S("Eye",[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);export{e as C,c as E};
